export interface IColor {
  bgClass: string;
  code: number;
  hex: string;
}
