export interface IOption {
  value: string;
  label: string | React.ReactNode;
}
